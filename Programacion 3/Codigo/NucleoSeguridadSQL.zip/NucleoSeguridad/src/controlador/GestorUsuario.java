/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import conexion.BaseDeDatos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Usuario;

/**
 *
 * @author 0535
 */
public class GestorUsuario {

    BaseDeDatos bd = new BaseDeDatos();
    Connection conexion = bd.estableceConexion();

    public void cerrarConexion() {
        try {
            conexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Usuario> dameListaUsuarios() {
        ResultSet rs = null;
        Usuario usuario = new Usuario();
        List<Usuario> usuarios = new ArrayList<Usuario>();
        GestorPerfil gPerfil = new GestorPerfil();
        GestorPersona gPersona = new GestorPersona();
        try {
            // Se crea un Statement, para realizar la consulta
            Statement s = conexion.createStatement();

            // Se realiza la consulta. Los resultados se guardan en el
            // ResultSet rs
            rs = s.executeQuery("select * from usuario");
            while (rs.next()) {
                usuario = new Usuario();
                usuario.setClave(rs.getString("clave"));
                usuario.setNombreUsuario(rs.getString("nombreusuario"));
                usuario.setId(rs.getLong("id"));
                usuario.setPerfil(gPerfil.damePerfilFila(rs.getLong("idperfil")));
                usuario.setPersona(gPersona.damePersonaFila(rs.getLong("idpersona")));
                usuarios.add(usuario);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    public void eliminarUsuario(Long valorId) {
        try {
            Statement st = conexion.createStatement();
            String sql = "DELETE FROM usuario WHERE id = " + valorId;
            int delete = st.executeUpdate(sql);

            if (delete == 1) {
                System.out.println("usuario Borrado");
            } else {
                System.out.println("usuario no Borrado");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insertarPersona(String usuario, String clave, String idPersona, String idPerfil) {
        try {
            // Se crea el objeto PreparedStatement.
            // Este precompila la sentencia SQL especificada.
            // Los signos de interrogación señalan el lugar en que deben establecerse los
            // parámetros antes de que se ejecute la sentencia.
            PreparedStatement ps = conexion.prepareStatement("INSERT INTO usuario (nombreusuario, clave, idpersona, idperfil) VALUES (?, ?, ?, ?)");

            // Se establecen los parámetros y se ejecuta la sentencia.
            ps.setString(1, usuario);
            ps.setString(2, clave);
            ps.setLong(3, new Long(idPersona));
            ps.setLong(4, new Long(idPerfil));
            ps.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BaseDeDatos.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public Usuario dameUsuarioFila(Long idFila) {
        ResultSet rs = null;
        Usuario usuario = new Usuario();
        GestorPerfil gPerfil = new GestorPerfil();
        GestorPersona gPersona = new GestorPersona();
        try {
            // Se crea un Statement, para realizar la consulta
            Statement s = conexion.createStatement();

            // Se realiza la consulta. Los resultados se guardan en el
            // ResultSet rs
            rs = s.executeQuery("select * from usuario WHERE id = " + idFila);
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setClave(rs.getString("clave"));
                usuario.setNombreUsuario(rs.getString("nombreusuario"));
                usuario.setId(rs.getLong("id"));
                usuario.setPerfil(gPerfil.damePerfilFila(rs.getLong("idperfil")));
                usuario.setPersona(gPersona.damePersonaFila(rs.getLong("idpersona")));
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usuario;
    }

    public void actualizarPersona(Long idUsuario, String usuario, String clave, String idPersona, String idPerfil) {
        try {
            // Se crea el objeto PreparedStatement.
            // Este precompila la sentencia SQL especificada.
            // Los signos de interrogación señalan el lugar en que deben establecerse los
            // parámetros antes de que se ejecute la sentencia.
            // Se establecen los parámetros y se ejecuta la sentencia.
            PreparedStatement ps = conexion.prepareStatement("UPDATE usuario SET nombreusuario = ?, clave = ?, idpersona = ?, idperfil = ? where id = ?");
            ps.setString(1, usuario);
            ps.setString(2, clave);
            ps.setLong(3, new Long(idPersona));
            ps.setLong(4, new Long(idPerfil));
            ps.setLong(5, idUsuario);
            ps.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BaseDeDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean validarUsuarioClave(String usuario, String clave) {
        ResultSet rs = null;
        try {
            String claveEncriptada = SHA1.SHA1(clave);
            System.out.println("CLAVE ENCRIPTADA " + claveEncriptada);
            // Se crea un Statement, para realizar la consulta
            /*Statement s = conexion.createStatement();
            // Se realiza la consulta. Los resultados se guardan en el
            // ResultSet rs
            //Cuidado pueden realizar un ataque por inyeccion de codigo
            rs = s.executeQuery("select * from usuario where nombreusuario = '" + usuario + "' AND clave = '" + claveEncriptada +"'");
             */
            PreparedStatement ps = conexion.prepareStatement("select * from usuario where nombreusuario = ? AND clave = ?");
            ps.setString(1, usuario);
            ps.setString(2, claveEncriptada);
            rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
